
public interface BookingObserver {
	void update(String message);
}
